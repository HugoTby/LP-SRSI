#!/bin/bash
# LACOUR xavier
# Script pour démarrer les services Apache2 , MySQL & SSH au début des travaux pratiques
echo "Démarrage du service Apache2"
sudo systemctl start apache2.service
echo "Démarrage du service MySQL"
sudo systemctl start mysql.service
echo "Démarrage du service SSH"
sudo systemctl start ssh.service
echo "Vérification"
sudo lsof -ni

# Pour réaliser une connexion SSH à partir de la machine hôote sur Kali faire:
# ssh iut@127.0.0.1 -p 22022
