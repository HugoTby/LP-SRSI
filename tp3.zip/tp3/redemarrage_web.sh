#!/bin/bash
# LACOUR xavier
# Script pour redémarrer les services Apache2 , MySQL
echo "Arrêt du service MySQL"
sudo systemctl stop mysql.service
echo "Arrêt du service Apache2"
sudo systemctl stop apache2.service
echo "Démarrage du service Apache2"
sudo systemctl start apache2.service
echo "Démarrage du service MySQL"
sudo systemctl start mysql.service
echo "Vérification"
sudo lsof -ni

