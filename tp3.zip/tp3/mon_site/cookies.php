<?php
	setcookie('mon_cookie', 'coucou');
?>
<html>
	<body>
		<h1>mon_site</h1>
		Un cookie a été ajouté.
		<p>Liste des cookies reçus : <?php print_r($_COOKIE) ?> </p>
	</body>
</html>
