<html>
	<head>
	<link rel="stylesheet" href="style.css" />
		<title>connexion</title>
	</head>
	<body>
		<h1>Mon_site</h1>
		<p>Bienvenue sur le formulaire de connexion<p>
		<br/><br/>
		<a href="https://cours.iut-orsay.fr">Moodle</a>
                <br/><br/>

	<form action="connexion_controleur.php" method="GET">
		<p>Pseudo :
		<input type="text" name="pseudo" /></p>
		<p>Mot de passe:
		<input type="password" name="mot_de_passe" /></p>
		<input type="submit" />
	</form>
	</body>

        <?php 
                if (!empty($_GET['message'])) 
                        echo "<font color='red'>".$_GET['message']."</font>";
        ?>
</html>
