<?php
echo "<h1> messages_liste.php</h1>";
        // Connexion à la base de données
        $db_server = "localhost";
        $db_username = "iut";
        $db_password = "orsay";
        $db_name = "mon_site";
        $co = new mysqli($db_server, $db_username, $db_password, $db_name);

	// Selection de la table message
	$sql = "SELECT * FROM messages";

	// Envoi de la requete
        $recordset = $co->query($sql) or die("Erreur: " . $co->error);

	// verification si la table est vide

	// Nombre de ligne dans la base
	$nb = mysqli_num_rows($recordset);
	echo "nombre de messages dans la base :  $nb <br/>";

	// affichage des messages
	if ($nb==0)
		echo "<br/>Pas de messages dans la base ";
	else
		echo "<br/>Liste des messages : <br/>";
		while ($row = $recordset->fetch_assoc()){
			echo $row['message'];
			echo "<br/>";
		}

        $co->close();
        exit;
?>
