<?php
	session_start();
?>
<h1>
<?php 
	echo 'bonjour ' . $_SESSION['pseudo']. '!'
?> 
 </h1>


        <a href="/mon_site/messages_liste.php">Liste des messages</a>
        </br></br>
	<a href="/mon_site/deconnexion_controleur.php">Déconnexion</a>
