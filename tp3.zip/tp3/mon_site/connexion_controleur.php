

<?php
	//On démarre une nouvelle session
	session_start();
	//On définit des variables de session
	$_SESSION["pseudo"] = $_GET["pseudo"];

?>
<?php
        // Connexion à la base de données
        $db_server = "localhost";
        $db_username = "iut";
        $db_password = "orsay";
        $db_name = "mon_site";
        $co = new mysqli($db_server, $db_username, $db_password, $db_name);

        // vérification du mot de passe
        $pseudo = $_GET["pseudo"];
        $mot_de_passe = $_GET["mot_de_passe"];

        // on cherche toutes les lignes qui contiennent ce pseudo et ce mot de passe
        $sql = "SELECT * FROM visiteurs WHERE pseudo = '$pseudo' AND mot_de_passe = '$mot_de_passe'";
        echo "<p> requête SQL : $sql</p>";
        $recordset = $co->query($sql) or die("Erreur: " . $co->error);
        $row = $recordset->fetch_assoc();

        // Si on a trouvé une ligne, alors les identifiants sont bons.
        if($row){
	header("Location: perso.php");
//        echo "Authentification réussie ! L'id du visiteur est ". $row['id'].".";
        }
        else {
        header("Location: connexion_formulaire.php?message=".urlencode('identifiants invalides'));
//        header("Location: connexion_formulaire.php");
//	header("Location: connexion_formulaire.html");
//        echo "Pseudo ou mot de passe incorrect.";
        }
        $co->close();
        exit;
?>





/*
<?php
	// Connexion à la base de données
	$db_server = "localhost";
	$db_username = "iut";
	$db_password = "orsay";
	$db_name = "mon_site";
	$co = new mysqli($db_server, $db_username, $db_password, $db_name);

	// vérification du mot de passe
	$pseudo = $_GET["pseudo"];
	$mot_de_passe = $_GET["mot_de_passe"];

	// on cherche toutes les lignes qui contiennent ce pseudo et ce mot de passe
	$sql = "SELECT * FROM visiteurs WHERE pseudo = '$pseudo' AND mot_de_passe =
	'$mot_de_passe'";
	echo "<p> requête SQL : $sql</p>";
	$recordset = $co->query($sql) or die("Erreur: " . $co->error);
	$row = $recordset->fetch_assoc();

	// Si on a trouvé une ligne, alors les identifiants sont bons.
	if($row){
	echo "Authentification réussie ! L'id du visiteur est ". $row['id'].".";
	}
	else {
	echo "Pseudo ou mot de passe incorrect.";
	}
	$co->close();
	exit;
?>
*/

/*
$recordset = $co->query($sql) or die("Erreur: " . $co->error);
... est la ligne qui envoie la requête SQL à la base de données. La réponse de la base est stockée dans
$recordset
$row = $recordset->fetch_assoc();
Permet de récupérer la première ligne de la réponse sous la forme d’un tableau associatif.
*/





/*
<p>Bonjour, </p>
</br></br>
<p>ce premier script en php affiche les paramètres reçus dans l’URL.</p>
</br></br>
</br>
*/


/*
<?php
        echo $_GET['pseudo'] ;
echo "<br/>";
echo $_GET['mot_de_passe'] ;
?>
</br></br>
*/
